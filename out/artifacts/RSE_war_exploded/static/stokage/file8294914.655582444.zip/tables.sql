
create table Pilote (Matricule integer(5),
	             Nom varchar(30) not null,
                               prenom	varchar(30) not null,
                               date_nais       date,
                              NB_heures integer(10),
                              constraint pk_pilote primary key(matricule));

create table Avion(     Code varchar(10),
		 marque  varchar(10) not null, 
		modele   varchar(10) not null,
		date_fab  date, 
		nb_heures integer(10),
		constraint pk_avion primary key (code));

create table Piloter(  Mt_Pilote integer(5), 
		Cd_avion varchar(10),
		constraint pk_piloter primary key (mt_pilote, cd_avion),
		constraint fkmtpilote foreign key(mt_pilote) references pilote(matricule),
		constraint fkcdavion  foreign key(cd_avion) references avion(code));

create table Vols(	num_vol varchar(6), 
		destination varchar(40) not null, 
		date_vol	date, 
		cd_avion	varchar(10), 
		constraint pk_vols primary key (num_vol),
		constraint fk_cd_avion foreign key( cd_avion) references avion(code));

create table Passager(Num_passage	integer(12),
		nom		varchar(30) not null,
		prenom		varchar(30) not null,
		classe		varchar(5),
		n_vol		varchar(6) not null,
		constraint pk_passager primary key (num_passage),
		constraint fg_n_vol foreign key(n_vol) references vols(num_vol));

